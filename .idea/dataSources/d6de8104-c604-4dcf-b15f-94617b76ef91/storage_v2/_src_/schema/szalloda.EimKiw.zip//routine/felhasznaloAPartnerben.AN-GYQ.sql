create
    definer = root@localhost procedure felhasznaloAPartnerben(IN id int)
BEGIN
SELECT p.azon FROM partner p INNER JOIN felhasznalok f on p.azon = f.id WHERE f.id = id;
END;

