create definer = root@localhost view arbevetelekevente as
select year(`fizetendok`.`mettol`) AS `evben`, sum(`fizetendok`.`fizetendo`) AS `arbevetel`
from `szalloda`.`fizetendok`
where `fizetendok`.`allapot` > 1
  and `fizetendok`.`allapot` < 5
group by year(`fizetendok`.`mettol`);

