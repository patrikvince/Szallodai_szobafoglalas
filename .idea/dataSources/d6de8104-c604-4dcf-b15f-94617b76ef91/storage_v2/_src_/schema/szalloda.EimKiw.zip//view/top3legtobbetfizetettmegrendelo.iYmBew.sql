create definer = root@localhost view top3legtobbetfizetettmegrendelo as
select `fizetendok`.`megrendelo` AS `megrendelo`, sum(`fizetendok`.`fizetendo`) AS `arbevetel`
from `szalloda`.`fizetendok`
where `fizetendok`.`mettol` <= curdate()
group by `fizetendok`.`megrendelo`
order by 2 desc
limit 3;

