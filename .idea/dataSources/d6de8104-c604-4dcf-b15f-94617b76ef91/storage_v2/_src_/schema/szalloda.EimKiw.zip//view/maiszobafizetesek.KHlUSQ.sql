create definer = root@localhost view maiszobafizetesek as
select `fizetendok`.`fog_szam`   AS `fog_szam`,
       `fizetendok`.`megrendelo` AS `megrendelo`,
       `fizetendok`.`szoba`      AS `szoba`,
       `fizetendok`.`mettol`     AS `mettol`,
       `fizetendok`.`meddig`     AS `meddig`,
       `fizetendok`.`fizetendo`  AS `fizetendo`
from `szalloda`.`fizetendok`
where `fizetendok`.`mettol` = curdate();

