create
    definer = root@localhost procedure igazolvanySzam(IN foglszam int)
BEGIN
SELECT p.igazolvany_szam FROM partner p INNER JOIN foglalasok f ON p.azon = f.megrendelo WHERE f.fog_szam = foglszam;
END;

