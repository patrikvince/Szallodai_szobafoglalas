create definer = root@localhost view fizetendok as
select `f`.`fog_szam`                                  AS `fog_szam`,
       `f`.`szoba`                                     AS `szoba`,
       `f`.`mettol`                                    AS `mettol`,
       `f`.`meddig`                                    AS `meddig`,
       `f`.`megrendelo`                                AS `megrendelo`,
       `f`.`fogl_datum`                                AS `fogl_datum`,
       `f`.`allapot`                                   AS `allapot`,
       `sz`.`sz_szam`                                  AS `sz_szam`,
       `sz`.`sz_tipus`                                 AS `sz_tipus`,
       `sz`.`kep`                                      AS `kep`,
       `fizetendofgv`(`sz`.`sz_tipus`, `f`.`fogl_datum`, `f`.`mettol`) *
       (to_days(`f`.`meddig`) - to_days(`f`.`mettol`)) AS `fizetendo`
from (`szalloda`.`foglalasok` `f`
         join `szalloda`.`szoba` `sz` on (`f`.`szoba` = `sz`.`sz_szam`));

