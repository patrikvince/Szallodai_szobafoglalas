create
    definer = root@localhost procedure mennyivelUtkozik(IN szoba1 int, IN mettol1 date, IN meddig1 date)
BEGIN
SELECT COUNT(*) as ossz FROM foglalasok WHERE szoba = szoba1 AND (mettol BETWEEN mettol1 AND DATE_ADD(meddig1, INTERVAL -1 DAY) OR mettol1 BETWEEN mettol AND DATE_ADD(meddig, INTERVAL -1 DAY));
END;

