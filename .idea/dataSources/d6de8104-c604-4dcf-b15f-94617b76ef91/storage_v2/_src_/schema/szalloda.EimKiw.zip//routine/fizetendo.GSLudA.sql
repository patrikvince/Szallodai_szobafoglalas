create
    definer = root@localhost procedure fizetendo(IN foglszam int)
BEGIN
DECLARE sztip varchar(1);
DECLARE foglDat date;
DECLARE foglMettol date;
DECLARE foglMeddig date;
DECLARE ara int;
SELECT sz.sz_tipus, f.fogl_datum, f.mettol, f.meddig INTO sztip, foglDat, foglMettol, foglMeddig 
FROM foglalasok f INNER JOIN szoba sz ON f.szoba = sz.sz_szam
WHERE fog_szam = foglszam;

#select sztip, foglDat, foglMettol, foglMeddig, DATEDIFF(foglMeddig, foglMettol);

SELECT CASE WHEN DATEDIFF(foglMettol, foglDat) < nappal_elotte THEN utana_ar ELSE elotte_ar END INTO ara
FROM szobaarak
where sz_tipus = sztip AND mettol = 
(
SELECT MAX(mettol)
FROM szobaarak 
where sz_tipus = sztip and mettol <= foglDat
);

SELECT ara * DATEDIFF(foglMeddig, foglMettol) as fizetendo;
END;

