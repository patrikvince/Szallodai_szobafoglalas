create
    definer = root@localhost function allapotMegszoritasFg(foglszam int) returns int
    RETURN
(
SELECT allapot from foglalasok WHERE fog_szam = foglszam
);

