create definer = root@localhost view arbevetelek as
select case when `fizetendok`.`mettol` <= curdate() then 'Befolyt' else 'Varhato' end AS `megjegyzes`,
       sum(`fizetendok`.`fizetendo`)                                                  AS `arbevetel`
from `szalloda`.`fizetendok`
group by case when `fizetendok`.`mettol` <= curdate() then 'Befolyt' else 'Varhato' end;

