create
    definer = root@localhost procedure hanyAgyas(IN fogl int)
BEGIN 
select szt.agyak_szama from foglalasok f INNER JOIN szoba sz ON f.szoba = sz.sz_szam INNER JOIN szobatipus szt ON sz.sz_tipus = szt.sz_tipus 
where fog_szam = fogl; 
END;

