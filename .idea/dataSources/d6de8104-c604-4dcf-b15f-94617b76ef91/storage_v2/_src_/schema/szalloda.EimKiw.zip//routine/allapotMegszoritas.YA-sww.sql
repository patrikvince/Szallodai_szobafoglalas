create
    definer = root@localhost procedure allapotMegszoritas(IN foglszam int)
BEGIN
SELECT allapot from foglalasok WHERE fog_szam = foglszam;
END;

