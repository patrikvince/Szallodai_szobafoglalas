create
    definer = root@localhost function fizetendofgv(sztip varchar(1), foglDat date, foglMettol date) returns int
    RETURN
(
SELECT CASE WHEN DATEDIFF(foglMettol, foglDat) < nappal_elotte THEN utana_ar ELSE elotte_ar END
FROM szobaarak
where sz_tipus = sztip AND mettol = 
(
	SELECT MAX(mettol)
	FROM szobaarak 
	where sz_tipus = sztip and mettol <= foglDat
)
);

