create
    definer = root@localhost procedure erkezesMegszoritas(IN foglszam int)
begin
select mettol from foglalasok where fog_szam=foglszam;
end;

